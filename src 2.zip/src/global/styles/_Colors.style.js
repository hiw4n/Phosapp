//Styles -------------------------------------------------------------
//Primary ---------------
export const COLORS = {

  primary:      '#222831',    // Un gris casi negro para fotógrafos
  accent:       '#00ADB5',     // Un turquesa para botones
  text:         '#222831',       // Blanco roto para que no canse la vista
  background:   '#EEEEEE',  // Gris intermedio


  //states
    inactive:     '#A9A9A9',

};